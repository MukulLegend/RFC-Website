"""
URL configuration for CU project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from atexit import register
from django.contrib import admin
from django.urls import include, path
from MBA import views
from django.conf import settings


urlpatterns = [
    path('admin/', admin.site.urls),
    
    path('home/', views.Home, name='home'),  
    path('about/', views.About, name='about'),
    path('contact/', views.contact_view, name='contact'),  
    path('', views.Login1, name='login'),
    path('login/', views.Login1, name='login'),
    path('register/', views.register, name='register'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('password-reset/', views.password_reset, name='password_reset'),
    path('change-password/', views.change_password, name='change_password'),
    path('chat/', views.chat, name='chat'),
    path('chat-api/', views.chat_api, name='chat_api'),
]
