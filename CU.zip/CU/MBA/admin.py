from django.contrib import admin

from .models import Contact, Register

# Register your models here.

@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ('name','email','contact_no')
    search_fields= ('name','email')
    list_filter= ('name','email')

@admin.register(Register)
class RegisterAdmin(admin.ModelAdmin):
    list_display = ('user', 'contact_no')
    search_fields =('user__username', 'user__email')
    list_filter = ('user__username', 'user__email')
    