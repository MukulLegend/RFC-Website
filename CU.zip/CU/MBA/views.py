from django.shortcuts import redirect, render
from .models import Contact, Register
from django.contrib.auth import authenticate, login
from .forms import RegisterForm, ChangePasswordForm
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Register
from django.contrib import messages
from django.contrib.auth import logout
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
from django.http import JsonResponse, HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt
import json
import os
import openai
from openai import OpenAI
from django.contrib.auth.models import User

import os

# Temporarily hardcode your OpenAI API key here for testing
api_key = "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"

client = OpenAI(api_key=api_key)

openai.api_key = api_key

# Create your views here.

@login_required(login_url='login')
def Home(request):
    username = request.user.username
    return render(request, "home.html", {'username': username})

# Removed duplicate Home view

def register(request):
    from .forms import RegisterModelForm
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        contact_form = RegisterModelForm(request.POST)
        if form.is_valid() and contact_form.is_valid():
            user = form.save()
            contact_no = contact_form.cleaned_data.get('contact_no')
            Register.objects.create(user=user, contact_no=contact_no)
            login_user = authenticate(
                username=user.username,
                password=form.cleaned_data.get('password1')
            )
        
            login(request, login_user)
            return redirect('home')
    else:
        form = RegisterForm()
        contact_form = RegisterModelForm()
    return render(request, 'register.html', {'form': form, 'contact_form': contact_form})

def About(request):
    return render(request,"about.html")

def logout_view(request):
    logout(request)
    return redirect('login')

def contact_view(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        email = request.POST.get("email")
        contact_no = request.POST.get("contact_no")  # match input name

        if name and email and contact_no:
            contact = Contact(name=name, email=email, contact_no=contact_no)
            contact.save()
            return render(request, "contact.html", {"message": "Your message has been sent!"})
        else:
            return render(request, "contact.html", {"message": "Please fill out all fields!"})

    return render(request, "contact.html")

from django.contrib import messages

def Login1(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home') 
        else:
            messages.error(request, 'Invalid username or password.')
            return render(request, 'login.html')
    else:
        return render(request, 'login.html')

from .forms import PasswordResetForm, ChangePasswordForm

def password_reset(request):
    if request.method == 'POST':
        form = PasswordResetForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            new_password = form.cleaned_data['new_password1']
            from django.contrib.auth.models import User
            try:
                user = User.objects.get(username=username)
                user.set_password(new_password)
                user.save()
                messages.success(request, 'Password has been reset successfully. Please login with your new password.')
                return redirect('login')
            except User.DoesNotExist:
                messages.error(request, 'User with this username does not exist.')
    else:
        form = PasswordResetForm()
    return render(request, 'password_reset.html', {'form': form})

@login_required(login_url='login')
def change_password(request):
    if request.method == 'POST':
        form = ChangePasswordForm(user=request.user, data=request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Important to keep the user logged in after password change
            messages.success(request, 'Your password was successfully updated!')
            return redirect('dashboard')
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = ChangePasswordForm(user=request.user)
    return render(request, 'change_password.html', {'form': form})

@login_required(login_url='login')
def dashboard(request):
    from .forms import UserProfileForm, RegisterModelForm
    user = request.user
    try:
        reg = Register.objects.get(user=user)
    except Register.DoesNotExist:
        reg = Register(user=user)
        reg.save()
    if request.method == 'POST':
        user_form = UserProfileForm(request.POST, instance=user)
        register_form = RegisterModelForm(request.POST, instance=reg)
        if user_form.is_valid() and register_form.is_valid():
            user_form.save()
            reg.user = user  # Ensure user is linked
            register_form.save()
            messages.success(request, 'Your profile has been updated successfully.')
            return redirect('dashboard')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        user_form = UserProfileForm(instance=user)
        register_form = RegisterModelForm(instance=reg)
    return render(request, 'dashboard.html', {
        'user_form': user_form,
        'register_form': register_form,
        'username': user.username,
    })

def chat(request):
    return render(request, 'chat.html')

from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse, HttpResponseBadRequest
import json

@csrf_exempt
def chat_api(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            user_message = data.get('message', '').strip()
            if not user_message:
                return JsonResponse({'error': 'Empty message'}, status=400)

            # Add system prompt for better AI behavior
            system_prompt = "You are a helpful assistant that provides clear and concise answers."

            # Prepare messages with system prompt and user message
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ]

            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=messages,
                max_tokens=300,
                temperature=0.7
            )
            ai_reply = response.choices[0].message.content.strip()
            if not ai_reply:
                return JsonResponse({'error': 'No reply from AI'}, status=500)
            return JsonResponse({'reply': ai_reply})
        except Exception as e:
            import traceback
            error_message = str(e) + "\n" + traceback.format_exc()
            print("Error in chat_api:", error_message)  # Added logging for debugging
            return JsonResponse({'error': error_message}, status=500)
    else:
        return HttpResponseBadRequest("Invalid request method.")
