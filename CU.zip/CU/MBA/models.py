
from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Contact(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    contact_no = models.CharField(max_length=15)
    def __str__(self):
        return self.name

class Register(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True, blank=True)
    contact_no = models.CharField(max_length=20, blank=True, null=True)

    def __str__(self):
        return self.user.username if self.user else "No User"
