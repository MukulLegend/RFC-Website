from django import forms
from django.contrib.auth.forms import UserCreationForm, PasswordChangeForm
from django.contrib.auth.models import User
from .models import Register

class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={
        "style": "width: 100%; padding: 0.75rem; margin-bottom: 1rem; border: 1px solid #cccccc; border-radius: 4px; font-size: 1rem; transition: border-color 0.3s;"
    }))
    contact_no = forms.CharField(max_length=20, required=False, label='Contact Number', widget=forms.TextInput(attrs={
        "style": "width: 100%; padding: 0.75rem; margin-bottom: 1rem; border: 1px solid #cccccc; border-radius: 4px; font-size: 1rem; transition: border-color 0.3s;"
    }))
    username = forms.CharField(widget=forms.TextInput(attrs={
        "style": "width: 100%; padding: 0.75rem; margin-bottom: 1rem; border: 1px solid #cccccc; border-radius: 4px; font-size: 1rem; transition: border-color 0.3s;"
    }))

    class Meta:
        model = User
        fields = ("username", "email", "password1", "password2")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['password1'].widget.attrs.update({
            "style": "width: 100%; padding: 0.75rem; margin-bottom: 1rem; border: 1px solid #cccccc; border-radius: 4px; font-size: 1rem; transition: border-color 0.3s;"
        })
        self.fields['password2'].widget.attrs.update({
            "style": "width: 100%; padding: 0.75rem; margin-bottom: 1rem; border: 1px solid #cccccc; border-radius: 4px; font-size: 1rem; transition: border-color 0.3s;"
        })

    def save(self, commit=True):
        user = super(RegisterForm, self).save(commit=False)
        user.email = self.cleaned_data["email"]
        if commit:
            user.save()
        return user

class PasswordResetForm(forms.Form):
    username = forms.CharField(max_length=100, label='Username')
    new_password1 = forms.CharField(widget=forms.PasswordInput, label='New Password')
    new_password2 = forms.CharField(widget=forms.PasswordInput, label='Confirm New Password')

    def clean(self):
        cleaned_data = super().clean()
        pw1 = cleaned_data.get("new_password1")
        pw2 = cleaned_data.get("new_password2")
        if pw1 and pw2 and pw1 != pw2:
            raise forms.ValidationError("Passwords do not match.")
        return cleaned_data

class ChangePasswordForm(PasswordChangeForm):
    old_password = forms.CharField(widget=forms.PasswordInput(attrs={'autocomplete': 'current-password', 'autofocus': True}), label='Old Password')
    new_password1 = forms.CharField(widget=forms.PasswordInput(attrs={'autocomplete': 'new-password'}), label='New Password')
    new_password2 = forms.CharField(widget=forms.PasswordInput(attrs={'autocomplete': 'new-password'}), label='Confirm New Password')

class UserProfileForm(forms.ModelForm):
    email = forms.EmailField(required=True, label='Email')

    class Meta:
        model = User
        fields = ['email']

class RegisterModelForm(forms.ModelForm):
    contact_no = forms.CharField(max_length=20, required=False, label='Contact Number')

    class Meta:
        model = Register
        fields = ['contact_no']
        # Add exclude or fields attribute to avoid ImproperlyConfigured error
